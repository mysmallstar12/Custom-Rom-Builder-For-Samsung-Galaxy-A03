package vn.kiet.a03volumebar;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.app.Activity;

public final class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(pad, pad, pad, pad);
        TextView info = new TextView(this);
        info.setText("A03 Volume Bar\n\nVuốt ngang ở sát thanh trạng thái để chỉnh âm lượng media. Kéo dọc xuống vẫn mở bảng thông báo.\n\nKhông quảng cáo • Không mạng • Không root");
        info.setTextSize(18);
        Button open = new Button(this);
        open.setText("Bật dịch vụ Trợ năng");
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(info);
        box.addView(open);
        setContentView(box);
    }
}
