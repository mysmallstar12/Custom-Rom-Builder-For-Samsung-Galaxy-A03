package vn.kiet.a03volumebar;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public final class VolumeAccessibilityService extends AccessibilityService {
    private WindowManager windowManager;
    private View strip;
    private AudioManager audio;
    private float downX, downY;
    private boolean horizontal;

    @Override protected void onServiceConnected() {
        AccessibilityServiceInfo info = getServiceInfo();
        info.flags |= AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
        setServiceInfo(info);
        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        installStrip();
    }

    private void installStrip() {
        strip = new View(this);
        strip.setBackgroundColor(Color.TRANSPARENT);
        strip.setOnTouchListener(this::handleTouch);
        int height = (int) (26 * getResources().getDisplayMetrics().density);
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, height,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP;
        windowManager.addView(strip, params);
    }

    private boolean handleTouch(View view, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getRawX(); downY = event.getRawY(); horizontal = false; return true;
            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - downX;
                float dy = event.getRawY() - downY;
                if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 12) {
                    horizontal = true;
                    int max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                    int value = Math.round(max * event.getRawX() / Math.max(1, view.getWidth()));
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, Math.max(0, Math.min(max, value)), AudioManager.FLAG_SHOW_UI);
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (!horizontal && event.getRawY() - downY > 18) performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
                return true;
            default: return true;
        }
    }

    @Override public void onInterrupt() { }
    @Override public void onDestroy() {
        if (windowManager != null && strip != null) windowManager.removeView(strip);
        super.onDestroy();
    }
}
